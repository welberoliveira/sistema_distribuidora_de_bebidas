INSERT INTO permissao VALUES (3, 'ROLE_CANCELAR_VENDA');

INSERT INTO grupo_permissao (codigo_grupo, codigo_permissao) VALUES (1, 3);