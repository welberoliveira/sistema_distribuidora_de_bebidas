package br.com.LeonardoPSouzaPortfolio.brewer.model.validation.group;

public interface CpfGroup {

}
