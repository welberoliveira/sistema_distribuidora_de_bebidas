package br.com.LeonardoPSouzaPortfolio.brewer.service.exception;

public class NomeCidadeJaCadastradaException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public NomeCidadeJaCadastradaException(String message) {
		super(message);
	}

}